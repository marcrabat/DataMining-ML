HWe have divided the project in two different folders:
 - Reports: Contains the report with our explanations of how the marketing campaign has to be done.
 - src: Divided in the subfolders:
	- data: The original dataset you have given to us to proceed with the study.
	- Model: The final model you should base on in order to achieve the better results for the campaign.
	* Apart from the previous folders, we have included also auxiliar information like what have been the most common attributes
	  as well as the InformationGain evaluation model used to achieve it.
