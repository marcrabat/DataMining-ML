function [theta, J_history] = gradientDescentMulti(X, y, theta, alpha, num_iters)
%GRADIENTDESCENTMULTI Performs gradient descent to learn theta
%   theta = GRADIENTDESCENTMULTI(x, y, theta, alpha, num_iters) updates theta by
%   taking num_iters gradient steps with learning rate alpha

% Initialize some useful values
m = length(y); % number of training examples
J_history = zeros(num_iters, 1);

for iter = 1:num_iters

    % ====================== YOUR CODE HERE ======================
    % Instructions: Perform a single gradient step on the parameter vector
    %               theta. 
    %
    % Hint: While debugging, it can be useful to print out the values
    %       of the cost function (computeCostMulti) and gradient here.
    %

	%Compute theta(1), theta(2) and theta(3)
    
    temp_0 =(1/m)*sum((theta(1)+theta(2).*X(:,2) + theta(3).*X(:,3))-y); %derivative theta0
    temp_1 =(1/m)*sum((((theta(1)+theta(2).*X(:,2) + theta(3).*X(:,3))-y)).*X(:,2)); %derivative theta1
    temp_2 =(1/m)*sum((((theta(1)+theta(2).*X(:,2) + theta(3).*X(:,3))-y)).*X(:,3)); %derivative theta2
    %Updating the values of theta
    theta(1)=theta(1)-alpha*(temp_0);
    theta(2)=theta(2)-alpha*(temp_1);
    theta(3)=theta(3)-alpha*(temp_2);
    
    % ============================================================

    % Save the cost J in every iteration    
    J_history(iter) = computeCostMulti(X, y, theta);

end

end
